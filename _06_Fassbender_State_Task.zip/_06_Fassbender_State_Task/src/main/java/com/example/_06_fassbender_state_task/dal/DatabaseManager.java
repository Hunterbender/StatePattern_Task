package com.example._06_fassbender_state_task.dal;

import java.sql.Connection;

public class DatabaseManager {
    private Connection connection = null;
    private String driver;
    private String url;
    private String user;
    private String pwd;


}
