package com.example._06_fassbender_state_task;

public interface TaskState {
    String assign();
    String start();
    String finish();
    String decline();
}
